﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingDemo
{
    public class Product :INotifyPropertyChanged
    {
        private int id;

        public int Id
        {
            get { return id; }
            set {
                id = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Id"));
            }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set {
                name = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Name"));
            }
        }

        private decimal unitcost;

        public decimal UnitCost
        {
            get { return unitcost; }
            set { 
                unitcost = value;
                OnPropertyChanged(new PropertyChangedEventArgs("UnitCost"));
                }
        }

        public Product()
        {
            Id = 1;
            Name = "IPHONE 6S";
            UnitCost = 60000;
        }

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
