﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for ListBinding.xaml
    /// </summary>
    public partial class ListBinding : Window
    {
        public ListBinding()
        {
            InitializeComponent();
            products = new List<Product>(){
                new Product(){ Id=101, Name="A",UnitCost=100},
                new Product(){ Id=102, Name="B",UnitCost=200},
                new Product(){ Id=103, Name="C",UnitCost=150},
                new Product(){ Id=104, Name="D",UnitCost=170},
                new Product(){ Id=105, Name="E",UnitCost=400},
                new Product(){ Id=106, Name="F",UnitCost=500}
            };
           this.DataContext = products;
           //lstProducts.ItemsSource = products;
        }
        List<Product> products;
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
